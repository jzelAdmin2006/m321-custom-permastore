#!/usr/bin/python3
#https://github.com/bazelbuild/bazel/issues/7091
#https://github.com/bazelbuild/rules_python/issues/382
import sys
import os
if os.__doc__ != 'td_bzl_fix':
    os.__doc__ = 'td_bzl_fix'
    sys.path = sys.path[1:]

import asyncio
from widget import run_widget
from src import api_gui
import grpclib.client
from typing import Callable, Awaitable, List, Tuple, Optional
import os
from aiohttp import web
from util import create_low_level_client, get_listen_host, simulation_retryable
import minio
import io
import aiohttp
import urllib.parse
import json
from dataclasses import dataclass
import traceback
import base64

bucket = "theship-permastore"
access_key = "theship"
secret_key = "theship1234"


def get_doc():
    width = 20
    return """
Der Permastore braucht einen S3 Storage, damit die Daten abelegt werden können.



Die Konfiguration ist hardcodiert:

|   |  |
| - | - |
| host       | {HOST} |
| bucket     | {BUCKET} |
| access key | {ACCESS_KEY} |
| secret_key | {SECRET_KEY} |

Der Permastore benötigt
- Ein Universal Coupler Module (das müsst ihr selber implementieren)
- für Station das dazugehörige Comm-Module


## Permastore Interface
Der Permastore kann verwendet werden, um Daten, die eine Station an eine andere Senden würde Zwischenzuspeichern. Ein Beispiel
```
# at Elyse Terminal
$ curl -XPOST http://{IP_AND_PORT}/download --data '{"source": "Elyse Terminal", "destination": "Artemis Station"}'
{"kind": "success"}

# at Artemis Station
$ curl -XPOST http://{IP_AND_PORT}/upload --data '{"source": "Elyse Terminal", "destination": "Artemis Station"}'
{"kind": "success"}
```


## Universal Coupler Module
Das Universal Coupler Module muss eine JSON HTTP Schnittstelle implementieren:
```
$ curl -XPOST 'http://{K8S_HOST}:2023/Artemis%20Station/receive'
{"kind": "success", "messages": [{"destination": "Shangris Station", "data": [0, 1, 2, 3, 4]}]}
```

```
$ curl -XPOST 'http://{K8S_HOST}:2023/Artemis%20Station/send' --data '{"source": "Shangris Station", "data": [0, 1, 2, 3]}'
{"kind": "success"}
```


""".replace('{HOST}', f'http://ip172-18-0-33-crnk1raim2rg00cu5b10-2016.direct.labs.play-with-docker.com'.ljust(width)
            ).replace('{ACCESS_KEY}', access_key.ljust(width)).replace('{SECRET_KEY}', secret_key.ljust(width)).replace(
                '{BUCKET}', bucket
            ).replace('{IP_AND_PORT}', f'{os.environ["K8S_HOST"]}:2019').replace('{K8S_HOST}', os.environ["K8S_HOST"])


async def universal_receive(source: str) -> List[Tuple[str, bytes]]:
    async with aiohttp.ClientSession() as session:
        url = f'http://{os.environ["K8S_HOST"]}:2023/{urllib.parse.quote(source)}/receive'
        async with session.post(url) as response:
            result = await response.json()
            if response.status != 200:
                raise Exception(f'calling {url} failed: {result}')
            return [(res['destination'], bytes(res['data'])) for res in result['messages']]


async def universal_send(destination: str, source: str, data: bytes):
    async with aiohttp.ClientSession() as session:
        url = f'http://{os.environ["K8S_HOST"]}:2023/{urllib.parse.quote(destination)}/send'
        async with session.post(
            url,
            data=json.dumps({
                'source': source,
                'data': [b for b in data]
            }),
        ) as response:
            result = await response.json()
            if response.status != 200:
                raise Exception(f'calling {url} failed: {result}')


def get_minio_client():
    return minio.Minio(
        f'ip172-18-0-33-crnk1raim2rg00cu5b10-2016.direct.labs.play-with-docker.com',
        access_key=access_key,
        secret_key=secret_key,
        secure=False,
    )


@simulation_retryable
async def widget_loop(update_widget,
                      simulation_client: api_gui.TheShipLowLevelClient) -> Callable[[dict], Awaitable[None]]:

    @dataclass
    class LogicError(Exception):
        error: str

    async def render_widget(state: str, messages_in_store: Optional[int]):
        await update_widget(
            {
                'title': 'Permastore',
                'group': 'status-only',
                'width': 3,
                'height': 2,
                'content': {
                    'kind':
                    'stack',
                    'content': [
                        {
                            'kind': 'text',
                            'text': state
                        },
                    ] + ([
                        {
                            'kind': 'text',
                            'text': f'Stored Messages: {messages_in_store}'
                        },
                    ]) if messages_in_store is not None else []
                }
            }
        )

    await render_widget("starting up", None)
    while True:
        try:

            async def connect_minio():
                client = get_minio_client()
                testdata = bytes([1, 2, 3, 4])
                client.put_object(
                    bucket_name=bucket, object_name='test.bin', data=io.BytesIO(testdata), length=len(testdata)
                )

                with client.get_object(bucket_name=bucket, object_name='test.bin') as response:
                    testdata_back = response.read()
                    if testdata_back != testdata:
                        raise LogicError(f'{testdata_back} != {testdata}')
                client.remove_object(bucket_name=bucket, object_name='test.bin')

            await connect_minio()
            await render_widget("connected to s3, waiting for requests", None)
            while True:
                client = get_minio_client()
                messages_in_store = len(list(client.list_objects(bucket)))
                await render_widget("connected to s3, waiting for requests", messages_in_store)
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            raise
        except LogicError as ex:
            await render_widget(ex.error, None)
            await asyncio.sleep(2)
        except Exception as ex:
            await render_widget(f'{ex}', None)
            await asyncio.sleep(2)


async def read_widget(messages):
    async for message in messages:
        pass


async def handle_root(request, simulation_client):
    return web.Response(text=f'Willkommen beim Permastore.')


async def handle_download(request):
    try:
        req = await request.json()
        req_source = req['source']
        req_destination = req['destination']
        all_data = await universal_receive(source=req_source)
        requested_data = [
            base64.b64encode(msg).decode('utf-8') for destination, msg in all_data if destination == req_destination
        ]
        if len(requested_data) == 0:
            return web.json_response(status=500, text=json.dumps({"kind": "error", 'message': 'no data received'}))
        else:
            client = get_minio_client()
            data_str = json.dumps(requested_data).encode('utf-8')
            client.put_object(
                bucket_name=bucket,
                object_name=f'{req_source}_to_{req_destination}',
                data=io.BytesIO(data_str),
                length=len(data_str),
            )
            return web.json_response(status=200, text=json.dumps({
                "kind": "success",
            }))
    except KeyboardInterrupt:
        raise
    except Exception as ex:
        traceback.print_exc()
        return web.json_response(status=500, text=json.dumps({"kind": "error", "message": str(ex)}))


async def handle_upload(request):
    try:
        req = await request.json()
        req_source = req['source']
        req_destination = req['destination']

        client = get_minio_client()
        with client.get_object(bucket_name=bucket, object_name=f'{req_source}_to_{req_destination}') as response:
            data = response.read()

        msgs = json.loads(data)
        for msg in msgs:
            await universal_send(source=req_source, destination=req_destination, data=base64.b64decode(msg))
        return web.json_response(status=200, text=json.dumps({"kind": "success", "note": f'{len(msgs)} messages sent'}))
    except KeyboardInterrupt:
        raise
    except Exception as ex:
        traceback.print_exc()
        return web.json_response(status=500, text=json.dumps({"kind": "error", "message": str(ex)}))


async def main() -> None:
    async with run_widget() as (messages, update_widget, update_doc):
        await update_doc(get_doc())
        async with grpclib.client.Channel(os.environ['SIMULATION_HOST'], 50051) as channel:
            simulation_client = create_low_level_client(channel)

            app = web.Application()
            app.add_routes(
                [
                    web.get('/', lambda request: handle_root(request, simulation_client)),
                    web.post('/download', handle_download),
                    web.post('/upload', handle_upload),
                ]
            )

            await asyncio.gather(
                web._run_app(app, host=get_listen_host(), port=2019),
                widget_loop(update_widget, simulation_client),
                read_widget(messages),
            )


if __name__ == '__main__':
    asyncio.run(main())
